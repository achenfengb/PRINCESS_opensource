#include <iostream>


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "FHE.h"
#include "timing.h"
#include "EncryptedArray.h"
#include <NTL/lzz_pXFactoring.h>

#include <cassert>
#include <sys/time.h>

#include <iostream>
#include <sys/time.h>
#include <NTL/ZZ.h>
#include <NTL/vector.h>
#include <NTL/vec_ZZ.h>
#include <time.h>
#include <vector>



NTL_CLIENT

typedef vector< vector<long> >      vector_vector_long;
//typedef vector< PlaintextArray >    vector_PtArray;

bool Encode(vector<long> , PlaintextArray& , const EncryptedArray& , const FHEPubKey& , Ctxt& );



int main()
{

    // < Parameters of HE scheme >
    
    long p=2;         // base of plaintext
    long r=10;         // exponent of plaintext -> Z_{2^9}
    long d=1;         // degree of field extension
    long c= 2;        // number of columns in key switching matrix
    long k= 80;       // security parameter
    long s=0;         // minimum number of slots
    long w=64;        // hamming distance
   
    long L=0;         // required level to be evaluated
    long m=5461;      // m'th cyclotomic of native plaintext space
    
    
    
    FILE * fp,* fp1, *fp2;
    
    char geno[311]={0};  // which of SNPs are inclued for each genotype
    
    char geno1[311][600]={0};  // buffer which has real SNPs
    char geno2[311][600]={0};  //unsigned long: no!
    long case_data[311][200],cont_data[311][200];  // buffer which has encodings of SNPS
    int  i,j=0,u,g,g1=0;
    int  ch,ch1;
 
   
    
    
    struct timeval t1, t2;
    double         elapsed=0.0;
    vector<double> exp_data;
    
    
    
    
     SetSeed(to_ZZ(time(0)));
    
    
    /***************************************************/
    // < Key Generation of HE scheme >
    /***************************************************/
    gettimeofday(&t1, 0);
    
    FHEcontext context(m, p, r);
    buildModChain(context, L, c);
    
    
    FHESecKey secretKey(context);
    const FHEPubKey& publicKey = secretKey;
    secretKey.GenSecKey(w);        // A Hamming-weight-w secret key
    
    ZZX G= ZZX(1, 1);              // the monomial X
    addSome1DMatrices(secretKey);  // compute key-switching matrices that we need
    EncryptedArray ea(context, G);
    
    long l = ea.size();
    printf("slots: %ld\n", l);
    
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Key Generation time = " << elapsed <<"ms" << endl;
    exp_data.push_back(elapsed);
    

    
    
    
    /*******************************************/
    /* < Open data of the case gp & control gp >
    /*******************************************/
    gettimeofday(&t1, 0);
    

    fp1= fopen("case_chr2_29504091_30044866.txt", "rb");   // Open data of the case group
    
    while(!feof(fp1)){
        ch=fgetc(fp1);
        //printf("%c",ch);
        if(ch=='r'){
            while(1){
                ch1=fgetc(fp1);
                if(ch1==0x0a){
                    while(1){
                        i= fread(geno1[j], sizeof(char), 600, fp1);
                        if(i!=1){break;}
                    }
                    break;
                }
            } // data read
            
            
            
            i=0; u=0;
            while(1){
                if(geno1[j][u]==geno1[j][u+1]){break;}
                case_data[j][i]=1;  //printf("%d %ld\n", i, case_data[j][i]);
                i++;
                u=3*i;
            }
            
            case_data[j][i]=0;   // :geno1[j][u]==geno1[j][u+1]
            geno[j]=geno1[j][u];   // geno[j]:character of encoding 0
            
            
            for(g=(i+1); g<200; g++){
                u=3*g;
                if(geno1[j][u]!=geno1[j][u+1])case_data[j][g]=1;
                else if(geno1[j][u]==geno[j])case_data[j][g]=0;
                else {case_data[j][g]=2;}
                //case gp
            }
    
            j++;
        }
    }
    fclose(fp1);

   


    j=0;
    fp2= fopen("control_chr2_29504091_30044866.txt", "rb");
    while(!feof(fp2)){
        ch=fgetc(fp2);
        //printf("%c",ch);
        if(ch=='s'){
            while(1){
                ch1=fgetc(fp2);
                if(ch1==0x0a){
                    while(1){
                        i= fread(geno2[j], sizeof(char), 600, fp2);
                        if(i!=1){break;}
                    }
                    break;
                }
            }
            
            
            for(g=0; g<200; g++){
                u=3*g;
                if(geno2[j][u]!=geno2[j][u+1])cont_data[j][g]=1;
                else if(geno2[j][u]==geno[j])cont_data[j][g]=0;
                else {cont_data[j][g]=2;}
            }
            j++;
        }
    }
    fclose(fp2);
    
    
#if defined(__DEBUG_)
    for(j=0; j<3; j++){
        for(i=0; i<600; i++){
            printf("%c", geno1[j][i]);
            printf("%c", geno2[j][i]);}

        
        for(i=0; i<200; i++){
            printf("%ld", case_data[j][i]);
            printf("%ld", cont_data[j][i]);}
        printf("\n");}
#endif
    
    
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Data Encoding time = "  << elapsed <<"ms"<< endl;
    exp_data.push_back(elapsed);
    
    
    
    
    
    
    
    /*******************************************************************/
    // < Encryption >
    /*******************************************************************/
    gettimeofday(&t1, 0);
    
    vector_vector_long  case_slot, cont_slot;
    vector<long> temp;
    
    PlaintextArray p0(ea);
    
    Ctxt           ct(publicKey);
    vector<Ctxt>   case_enc,cont_enc;
    
    
    
    //encryption of case group
    // Patient P0
    for (j=0; j<311; j++) temp.push_back(case_data[j][0]);
    for (g=311; g<l; g++) temp.push_back(0);
    case_slot.push_back(temp);
    Encode(case_slot[0], p0, ea, publicKey, ct);
    case_enc.push_back(ct);
    ct.clear();
    
    // Patient P1,,,,P199
    for(i=1; i<200; i++){
        for (j=0; j<311; j++) temp[j]=case_data[j][i];
        case_slot.push_back(temp);
        Encode(case_slot[i], p0, ea, publicKey, ct);
        case_enc.push_back(ct); ct.clear();
    }
    
    
    // encryption of control group
    for(i=0; i<200; i++){
        for (j=0; j<311; j++) temp[j]=cont_data[j][i];
        cont_slot.push_back(temp);
        Encode(cont_slot[i], p0, ea, publicKey, ct);
        cont_enc.push_back(ct); ct.clear();
    }
    
    
    
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Encryption time = " << elapsed <<"ms" << endl;
    exp_data.push_back(elapsed);

    
    /*******************************************************************/
    // < Evaluation >
    /*******************************************************************/
    gettimeofday(&t1, 0);
    
    
    for(i=0; i<100; i++){
        j=2*i;
        case_enc[j]+=case_enc[j+1];
        cont_enc[j]+=cont_enc[j+1];
    }
    
    for(i=0; i<50; i++) {
        j=4*i;
        case_enc[j]+=case_enc[j+2];
        cont_enc[j]+=cont_enc[j+2];
    }
    for(i=0; i<25; i++) {
        j=8*i;
        case_enc[j]+=case_enc[j+4];
        cont_enc[j]+=cont_enc[j+4];
    }
    for(i=0; i<12; i++) {
        j=16*i;
        case_enc[j]+=case_enc[j+8];
        cont_enc[j]+=cont_enc[j+8];
    }
    for(i=0; i<6; i++)  {
        j=32*i;
        case_enc[j]+=case_enc[j+16];
        cont_enc[j]+=cont_enc[j+16];
    }
    
    for(i=0; i<3; i++)  {
        j=64*i;
        case_enc[j]+=case_enc[j+32];
        cont_enc[j]+=cont_enc[j+32];
    }
    for(i=0; i<2; i++)  {
        j=128*i;
        case_enc[j]+=case_enc[j+64];
        cont_enc[j]+=cont_enc[j+64];
    }
    
    
    case_enc[0]+=case_enc[128];  //case_enc[0]: one Allele count of case group

    cont_enc[0]+=cont_enc[128];  //case_enc[0]: one Allele count of control group
    

    
    // chi2_den: a+c
    Ctxt ct_den=case_enc[0];
    ct_den+= cont_enc[0];
    
    // chi2_num: a-c
    Ctxt ct_num=case_enc[0];
    ct_num-= cont_enc[0];
    
    
    
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Evaluation time for chi2 = " << elapsed <<"ms"<< endl;
    exp_data.push_back(elapsed);
    
    

    /*******************************************************************/
    // < Decryption >
    /*******************************************************************/
    gettimeofday(&t1, 0);
    
    PlaintextArray pden(ea),pnum(ea);
    
    
    // Chi2-Test
    ea.decrypt(ct_den,secretKey,pden);
    ea.decrypt(ct_num,secretKey,pnum);
    
    
#if defined(__DEBUG_)
    pden.print(cout); cout << endl;
    pnum.print(cout); cout << endl;
#endif
    
    
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Decryption time for chi2 = " << elapsed << "ms" << endl;
    exp_data.push_back(elapsed);

    
    
    /*******************************************************************/
    // < Decoding >
    /*******************************************************************/
    gettimeofday(&t1, 0);
    
    vector<long>  chi_den, chi_num;
    
    vector<double> chi;
    
    
    pden.decode(chi_den); //(long) denominator of chi2 test (a+c)
    pnum.decode(chi_num); //(long) denominator of chi2 test (a-c)
    
    
    double temp1;
    
    for(i=0; i<311; i++){
        
        temp1= 800-(chi_den[i]);
        chi_den[i]*=temp1;        // (a+c)*(800-(a+c))
        
        
        if(chi_num[i]>512){
            temp1=(chi_num[i]-1024); temp1=(800*temp1*temp1);
        }
        else{temp1=(800*chi_num[i]*chi_num[i]);}
        
        //cout << temp1<< endl;
        chi.push_back(temp1/chi_den[i]);
    }
    


    
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Decoding time for chi2 = " << elapsed << "ms" << endl;
    exp_data.push_back(elapsed);
    
#if 1
    printf("%lf", chi[0]);
#endif
    
    return 0;
    
}








//! @fn     bool generatePlaintexts(const unsigned long N, GF2XVec& listOfPlaintexts)
//! @brief  Encrypt the input plaintext slots into the output ciphertext
//! @return
bool Encode(vector<long> input, PlaintextArray& pt, const EncryptedArray& ea, const FHEPubKey& pk, Ctxt& ct)
{
    pt.encode(input);
    ea.encrypt(ct, pk, pt);
    
    return true;
}




