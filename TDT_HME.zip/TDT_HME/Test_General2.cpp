/* Copyright (C) 2012,2013 IBM Corp.
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
 
/* Test_Permutations.cpp - Applying plaintext permutation to encrypted vector
 */
#include <NTL/ZZ.h>
NTL_CLIENT
 
#include "NumbTh.h"
#include "timing.h"
#include "permutations.h"
#include "EncryptedArray.h"
#include <NTL/lzz_pXFactoring.h>
#include <fstream>
#include <time.h>
#include <cassert>
#include <cstdio>
#include <stdlib.h>
#include <algorithm>
#include <cmath>
#include <math.h>
 
 
#ifdef DEBUG
#define debugCompare(ea,sk,p,c) {\
PlaintextArray pp(ea);\
ea.decrypt(c, sk, pp);\
if (!pp.equals(p)) { cerr << "oops\n"; exit(0); }\
}
#else
#define debugCompare(ea,sk,p,c)
#endif
 
int main(int argc, char *argv[])
{
    clock_t start_time=clock();
 
 
 
    long p=2, r=32, L=4, c=2, w=64,d=1,k=80; // parameters
    long m = FindM(k, L, c, p, d, 0, 0, true);
 
 
   
    ofstream file("publicKey.txt",ios::out | ios::trunc | ios::binary);
    ofstream file1("privateKey.txt",ios::out | ios::trunc | ios::binary);
 
    /*
    int iy[initialnum]={1,0,0,1,0,0,1};
    int ix1[initialnum]={0,0,0,0,0,1,1};
    int ix2[initialnum]={0,2,2 ,1,1 ,0,2};
     
   */
    /*
    int iy[initialnum]={1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int ix1[initialnum]={1,0,0,1,0,0,0,0,1,1,1,0,1,1,0,1,1,0,1,1,0,1,1,0,1,0,1,1,1,1};
    int ix2[initialnum]={0,2,2,0,2,0,2,2,0,2,1,1,0,2,1,2,2,0,1,2,0,2,1,1,2,0,2,1,1,0};
    */
    
   // ***********************************
   // int pm=21;// for ysize =7
    
   //**************************************
 
    ZZX G;                 // defines the plaintext space
    // Some code here to choose all the parameters, perhaps
    // using the fucntion FindM(...) in the FHEContext module
    FHEcontext context(m, p, r);
    // initialize context
    buildModChain(context, L, c);
    if(d==0)
        G=context.alMod.getFactorsOverZZ()[0];
    else
        G=makeIrredPoly(p,d);
    // modify the context, adding primes to the modulus chain
    FHESecKey secretKey(context);
    
    // construct a secret key structure associated with the context
    const FHEPubKey& publicKey = secretKey;
    // an "upcast": FHESecKey is a subclass of FHEPubKey
    secretKey.GenSecKey(w);
    // actually generate a secret key with Hamming weight w
   addSome1DMatrices(secretKey);
    // compute key-switching matrices that we need
 
    EncryptedArray ea(context, G);
    long nslots=ea.size();
    cout<<"nslots:"<<nslots<<endl;
    file<<publicKey;
    file1<<secretKey;
    file.close();
    file1.close();
     
    clock_t end_time=clock();
     
    cout<< "Running time of key generation time is: "<<static_cast<double>(end_time-start_time)/CLOCKS_PER_SEC<<"s"<<endl;
    return 0;
     
}