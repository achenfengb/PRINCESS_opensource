#include <iostream>


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "FHE.h"
#include "timing.h"
#include "EncryptedArray.h"
#include <NTL/lzz_pXFactoring.h>

#include <cassert>
#include <sys/time.h>

#include <iostream>
#include <sys/time.h>
#include <NTL/ZZ.h>
#include <NTL/vector.h>
#include <NTL/vec_ZZ.h>
#include <time.h>
#include <vector>

NTL_CLIENT

typedef vector< vector<long> >      vector_vector_long;

//! @fn     bool generatePlaintexts(const unsigned long N, GF2XVec& listOfPlaintexts)
//! @brief  Encrypt the input plaintext slots into the output ciphertext
//! @return
bool Encode(vector<long> input, PlaintextArray& pt, const EncryptedArray& ea, const FHEPubKey& pk, Ctxt& ct)
{
    pt.encode(input);
    ea.encrypt(ct, pk, pt);
    
    return true;
}


void test1(const FHEPubKey& publicKey, FHESecKey& secretKey, const EncryptedArray& ea, int l)
{
    PlaintextArray p0(ea);
    
    Ctxt           ct1(publicKey), ct2(publicKey), ct3(publicKey), ct4(publicKey), ct5(publicKey), ct6(publicKey), ct7(publicKey), ct8(publicKey);
    vector<long> temp1, temp2, temp3, temp4, temp5, temp6, temp7, temp8;
    vector<Ctxt>   enc_data1,enc_data2, enc_data3, enc_data4, enc_data5, enc_data6, enc_data7, enc_data8;
    
    for(int i = 0; i < 250; i++)
    {
        temp1.push_back(20);
        temp2.push_back(30);
        temp3.push_back(40);
        temp4.push_back(20);
        temp5.push_back(20);
        temp6.push_back(30);
        temp7.push_back(40);
        temp8.push_back(20);
    }
    
    for(int i = 250; i < l; i++)
    {
        temp1.push_back(0);
        temp2.push_back(0);
        temp3.push_back(0);
        temp4.push_back(0);
        temp5.push_back(0);
        temp6.push_back(0);
        temp7.push_back(0);
        temp8.push_back(0);
    }
    
    Encode(temp1, p0, ea, publicKey, ct1);
    Encode(temp2, p0, ea, publicKey, ct2);
    Encode(temp3, p0, ea, publicKey, ct3);
    Encode(temp4, p0, ea, publicKey, ct4);
    Encode(temp1, p0, ea, publicKey, ct5);
    Encode(temp2, p0, ea, publicKey, ct6);
    Encode(temp3, p0, ea, publicKey, ct7);
    Encode(temp4, p0, ea, publicKey, ct8);
    
    ct1 += ct2;
    ct3 += ct4;
    ct5 += ct6;
    ct7 += ct8;
    
    ct1.multiplyBy(ct3);
    ct5.multiplyBy(ct7);
    
    ct1.multiplyBy(ct5);
    
    PlaintextArray pden(ea);
    ea.decrypt(ct1,secretKey,pden);
}

int main()
{
        // < Parameters of HE scheme >
    
    long p=2;         // base of plaintext
    long r=32;         // exponent of plaintext -> Z_{2^9}
    long d=1;         // degree of field extension
    long c= 2;        // number of columns in key switching matrix
    long k= 80;       // security parameter
    long s=0;         // minimum number of slots
    long w=64;        // hamming distance
   
    long L=4;         // required level to be evaluated
    long m=5461;      // m'th cyclotomic of native plaintext space
    
    
    struct timeval t1, t2;
    double         elapsed=0.0;
    vector<double> exp_data;
    
    SetSeed(to_ZZ(time(0)));
    
    /***************************************************/
    // < Key Generation of HE scheme >
    /***************************************************/
    gettimeofday(&t1, 0);
    
    FHEcontext context(m, p, r);
    buildModChain(context, L, c);
    
    
    FHESecKey secretKey(context);
    const FHEPubKey& publicKey = secretKey;
    secretKey.GenSecKey(w);        // A Hamming-weight-w secret key
    
    ZZX G= ZZX(1, 1);              // the monomial X
    addSome1DMatrices(secretKey);  // compute key-switching matrices that we need
    EncryptedArray ea(context, G);
    
    long l = ea.size();
    printf("slots: %ld\n", l);
    
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Key Generation time = " << elapsed <<"ms" << endl;
    exp_data.push_back(elapsed);
    
    gettimeofday(&t1, 0);
    
    for(int i = 0; i < 40; i++)
    {
        printf("The time is %d\n", i);
        test1(publicKey, secretKey, ea, l);
    }
     
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Testing time for chi2 = " << elapsed << "ms" << endl;
    exp_data.push_back(elapsed);
    
    return 0;
}

