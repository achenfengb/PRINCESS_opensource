#include <stdlib.h>
#include <string.h>


#include "FHE.h"
#include "timing.h"
#include "EncryptedArray.h"

#include <cassert>
#include <sys/time.h>
#include <fstream>
#include <sys/time.h>
#include <NTL/ZZ.h>
#include <NTL/vector.h>
#include <NTL/vec_ZZ.h>
#include <time.h>
#include <vector>
#include "NumbTh.h"
#include "timing.h"
#include "permutations.h"
#include "EncryptedArray.h"
#include <NTL/lzz_pXFactoring.h>
#include <fstream>
#include <time.h>
#include <cassert>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <math.h>


NTL_CLIENT

#define RAND_MOD 200

typedef vector< vector<long> >      vector_vector_long;

//! @fn     bool generatePlaintexts(const unsigned long N, GF2XVec& listOfPlaintexts)
//! @brief  Encrypt the input plaintext slots into the output ciphertext
//! @return
bool Encode(vector<long> input, PlaintextArray& pt, const EncryptedArray& ea, const FHEPubKey& pk, Ctxt& ct)
{
    pt.encode(input);
    ea.encrypt(ct, pk, pt);
    
    return true;
}

void generateRndBC(vector<long>& b1, vector<long>& b2, vector<long>& c1, vector<long>& c2, const int N)
{
    b1.push_back(rand()%RAND_MOD);
    b2.push_back(rand()%RAND_MOD);
    c1.push_back(rand()%RAND_MOD);
    c2.push_back(rand()%RAND_MOD);
        
    for(int n = 1; n < N; n++){
        b1.push_back(0);
        b2.push_back(0);
        c1.push_back(0);
        c2.push_back(0);
    }
}

void calTDT(vector<long>& vec_b1, vector<long>& vec_b2, vector<long>& vec_c1, vector<long>& vec_c2, long* res_neu, long* res_den)
{
    const int N = vec_b1.size();
    long b, c;
    
    for(int n = 0; n < N; n++)
    {
        b = vec_b1[n] + vec_b2[n];
        c = vec_c1[n] + vec_c2[n];
           
        res_neu[n] = (b - c) * (b - c);
        res_den[n] = (b + c);
    } 
}

double test1(     const FHEPubKey& publicKey, 
                FHESecKey& secretKey, 
                const EncryptedArray& ea, 
                int l,

                vector<long>& b1,
                vector<long>& b2,
                vector<long>& c1,
                vector<long>& c2,
                
                ofstream& file_ct_b1,
                ofstream& file_ct_b2,
                ofstream& file_ct_c1,
                ofstream& file_ct_c2,
                ofstream& file_ct_b_p_c,
                ofstream& file_ct_c_m_c_2,
                
                PlaintextArray& pden_b_p_c,
                PlaintextArray& pden_b_m_c 
        )
{
    PlaintextArray p0(ea);
    
    Ctxt ct_b1(publicKey), ct_b2(publicKey), ct_c1(publicKey), ct_c2(publicKey);
    
    Encode(b1, p0, ea, publicKey, ct_b1);
    Encode(b2, p0, ea, publicKey, ct_b2);
    Encode(c1, p0, ea, publicKey, ct_c1);
    Encode(c2, p0, ea, publicKey, ct_c2);
    file_ct_b1 << ct_b1;
    file_ct_b2 << ct_b2;
    file_ct_c1 << ct_c1;
    file_ct_c2 << ct_c2;
    
    struct timeval t1, t2;
    double  elapsed=0.0;
    gettimeofday(&t1, 0);
    ct_b1 += ct_b2;
    ct_c1 += ct_c2;
    
    ct_b1 += ct_c1;
    ct_c1 += ct_c1;
    ct_c1 -= ct_b1;
    
    ct_c1.square();
    gettimeofday(&t2, 0);
    
    file_ct_b_p_c << ct_b1;
    file_ct_c_m_c_2 << ct_c1;
    
    file_ct_b1.flush();
    file_ct_b2.flush();
    file_ct_c1.flush();
    file_ct_c2.flush();
    
    file_ct_b_p_c.flush();
    file_ct_c_m_c_2.flush();
    
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    
    ea.decrypt(ct_b1,secretKey,pden_b_p_c);
    ea.decrypt(ct_c1,secretKey,pden_b_m_c);
    
    return elapsed;
}

int main()
{
        // < Parameters of HE scheme >
        
    int data_len = 10000;
    
    long p=	401;         // base of plaintext
    long r= 2;         // exponent of plaintext -> Z_{2^9}
    long d= 1;         // degree of field extension
    long c= 2;        // number of columns in key switching matrix
    long k= 80;       // security parameter
    long s=0;         // minimum number of slots
    long w= 64;        // hamming distance
   
    long L=38;         // required level to be evaluated
    long m;//=5461;      // m'th cyclotomic of native plaintext space
    
    m = FindM(k, L, c, p, d, s, 0, true);
    //m = 2300;
  
    
    struct timeval t1, t2;
    double         elapsed=0.0;
    double         elapsed1 = 0.0;
    
    ofstream file_ct_b1("ct_b1.txt",ios::out | ios::trunc | ios::binary);
    ofstream file_ct_b2("ct_b2.txt",ios::out | ios::trunc | ios::binary);
    ofstream file_ct_c1("ct_c1.txt",ios::out | ios::trunc | ios::binary);
    ofstream file_ct_c2("ct_c2.txt",ios::out | ios::trunc | ios::binary);
    ofstream file_ct_b_p_c("ct_b_p_c.txt",ios::out | ios::trunc | ios::binary);
    ofstream file_ct_c_m_c_2("ct_c_m_c_2.txt",ios::out | ios::trunc | ios::binary);
    ofstream file_TDT_profile("TDT_Profile.txt",ios::out | ios::trunc | ios::binary);
    ofstream file_TDT_result("TDT_res.txt",ios::out | ios::trunc | ios::binary);

    SetSeed(to_ZZ(time(0)));
    
    file_TDT_profile << "parameters " << endl;
    file_TDT_profile << "k (security paramter): " << k << endl;
    file_TDT_profile << "p (base of platintext): " << p << endl;
    file_TDT_profile << "r (exponent of platintext): " << r << endl;
    file_TDT_profile << "d (degree of field extension): " << d << endl;
    file_TDT_profile << "c (number of columns in key switching matrix): " << c << endl;
    file_TDT_profile << "w (hamming distance): " << m << endl;
    file_TDT_profile << "L (required level to be evaluated): " << L << endl;
    file_TDT_profile << "m (m'th cyclotomic of native plaintext space): " << m << endl;
    
    file_TDT_profile.flush();
    
    /***************************************************/
    // < Key Generation of HE scheme >
    /***************************************************/
    gettimeofday(&t1, 0);
    
    FHEcontext context(m, p, r);
    buildModChain(context, L, c);
    
    
    FHESecKey secretKey(context);
    const FHEPubKey& publicKey = secretKey;
    secretKey.GenSecKey(w);        // A Hamming-weight-w secret key
    
    ZZX G= ZZX(1, 1);              // the monomial X
    addSome1DMatrices(secretKey);  // compute key-switching matrices that we need
    EncryptedArray ea(context, G);
    
    long l = ea.size();
    printf("slots: %ld\n", l);
    file_TDT_profile << "slots #: " << l << endl;
     
    
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Key Generation time = " << elapsed <<"ms" << endl;
    file_TDT_profile << "Key Generation time = " << elapsed <<"ms" << endl;
    
    gettimeofday(&t1, 0);
    
    int iters = (data_len + l - 1) / l; 

    for(int i = 0; i < iters; i++)
    {
        printf("The time is %d\n", i);
        vector<long> b1, b2, c1, c2, res_den1, res_neu1;
        generateRndBC(b1, b2, c1, c2, l);
        PlaintextArray pt_b1(ea);
        PlaintextArray pt_b2(ea);
        PlaintextArray pt_c1(ea);
        PlaintextArray pt_c2(ea);
        
        long* res_den = new long[l];
        long* res_neu = new long[l];
        calTDT(b1, b2, c1, c2, res_neu, res_den);
        
        pt_b1.encode(b1);
        pt_b2.encode(b2);
        pt_c1.encode(c1);
        pt_c2.encode(c2);
        
        pt_b1.add(pt_b2);
        pt_c1.add(pt_c2);
        pt_b1.add(pt_c1);
        pt_c1.add(pt_c1);
        pt_c1.sub(pt_b1);
        pt_c1.mul(pt_c1);
        
        PlaintextArray pden_b_p_c(ea);
        PlaintextArray pden_b_m_c(ea);
        
        elapsed1 += test1(publicKey, secretKey, ea, l, b1, b2, c1, c2, file_ct_b1, file_ct_b2, file_ct_c1, 
                    file_ct_c2, file_ct_b_p_c, file_ct_c_m_c_2, pden_b_p_c, pden_b_m_c);
        cout << "elapsed: " << elapsed1 << endl;
            
        pden_b_p_c.decode(res_den1);
        pden_b_m_c.decode(res_neu1);
        
        for(int m0 = 0; m0 < 1; m0++)
        {
            file_TDT_result << res_neu1[m0] <<"\t"<< res_den1[m0] << "\t" << res_neu[m0] << "\t" << res_den[m0] << endl;  
        }
        
        if(!pden_b_p_c.equals(pt_b1) || !pden_b_m_c.equals(pt_c1)){
            cout << "error!"<<endl;
        }
    }
     
    gettimeofday(&t2, 0);
    elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
    elapsed += (t2.tv_usec - t1.tv_usec) / 1000.0;
    cout << "Running time excluding enc and dec = " << elapsed1 << "ms" << endl;
    cout << "Running time including enc and dec = " << elapsed << "ms" << endl;
    file_TDT_profile << "Running time excluding enc and dec = " << elapsed1 << "ms" << endl;
    file_TDT_profile << "Running time ciphertext operation = " << elapsed-elapsed1 << "ms" << endl;
    //exp_data.push_back(elapsed);

    file_ct_b1.close();
    file_ct_b2.close();
    file_ct_c1.close();
    file_ct_c2.close();
    file_ct_b_p_c.close();
    file_ct_c_m_c_2.close();
    file_TDT_profile.close();
    file_TDT_result.close();
    
    return 0;
}

