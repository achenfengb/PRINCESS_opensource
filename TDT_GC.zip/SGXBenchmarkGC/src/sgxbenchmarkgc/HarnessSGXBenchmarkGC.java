package sgxbenchmarkgc;

import org.junit.Assert;

import flexsc.CompEnv;
import flexsc.Mode;
import flexsc.Party;


public class HarnessSGXBenchmarkGC<T> {
	final int len = 32;
	final int offset =10;
	public abstract class Helper {
		Mode m;
		double a0,a1, b0, b1;
		public Helper(double a0, double b0, double a1, double b1, Mode m) {
			this.m = m;
			this.b0 = b0;
			this.a0 = a0;
                        this.a1 = a1;
                        this.b1 = b1;
		}
		public abstract T[] secureCompute(T[] a0, T[] b0, T[] a1, T[] b1, int offset, CompEnv<T> env) throws Exception;
		public abstract double plainCompute(double a0, double b0, double a1, double b1);
	}
	
	class GenRunnable extends network.Server implements Runnable {
		Helper h;
		double z;

		GenRunnable (Helper h) {
			this.h = h;
		}

		public void run() {
			try {
				listen(54321);
				@SuppressWarnings("unchecked")
				CompEnv<T> gen = CompEnv.getEnv(h.m, Party.Alice, is, os);
				
				T[] fgc1 = gen.inputOfAliceFixedPoint(h.a0, len, offset);
				T[] fgc2 = gen.inputOfBobFixedPoint(0, len, offset);
                                T[] fgc3 = gen.inputOfAliceFixedPoint(h.b0, len, offset);
                                T[] fgc4 = gen.inputOfBobFixedPoint(0, len, offset);
                                
				T[] re = h.secureCompute(fgc1, fgc3, fgc2, fgc4, offset, gen);
									
				z = gen.outputToAliceFixedPoint(re, offset);

				disconnect();
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(1);
			}
		}
	}

	class EvaRunnable extends network.Client implements Runnable {
		Helper h;

		EvaRunnable (Helper h) {
			this.h = h;
		}

		public void run() {
			try {
				connect("localhost", 54321);	
				@SuppressWarnings("unchecked")
				CompEnv<T> eva = CompEnv.getEnv(h.m, Party.Bob, is, os);
				
				T[] fgc1 = eva.inputOfAliceFixedPoint(0, len, offset);
				T[] fgc2 = eva.inputOfBobFixedPoint(h.a1, len, offset);
                                T[] fgc3 = eva.inputOfAliceFixedPoint(0, len, offset);
                                T[] fgc4 = eva.inputOfBobFixedPoint(h.b1, len, offset);
                                
				T[] re = h.secureCompute(fgc1, fgc3, fgc2, fgc4, offset, eva);
									
				eva.outputToAliceFixedPoint(re, offset);

				
				disconnect();
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(1);
			}
		}
	}

	public void runThreads(Helper h) throws Exception {
		GenRunnable gen = new GenRunnable(h);
		EvaRunnable eva = new EvaRunnable(h);

		Thread tGen = new Thread(gen);
		Thread tEva = new Thread(eva);
		tGen.start(); Thread.sleep(1);
		tEva.start();
		tGen.join();

		
		//if(Math.abs(h.plainCompute(h.a0, h.b0, h.a1, h.b1)-gen.z)<1E-5)
			//System.out.print(Math.abs(h.plainCompute(h.a0, h.b0, h.a1, h.b1)-gen.z)+" "+gen.z+" "+h.plainCompute(h.a0, h.b0, h.a1, h.b1)+" "+h.a0+" "+h.b0 + " " + h.a1 + " " + h.b1 + "\n");
//		Assert.assertTrue(Math.abs(h.plainCompute(h.a, h.b)-gen.z)<1E-5);
	}
}