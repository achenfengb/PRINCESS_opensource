package sgxbenchmarkgc;

import flexsc.CompEnv;
import flexsc.Mode;
import gc.GCSignal;

import java.util.Random;

import org.junit.Test;

import test.harness.TestFixedPoint;
import circuits.FixedPointLib;


public class SGXBenchmarkGC extends HarnessSGXBenchmarkGC<GCSignal> {

	@Test
	public void testAllCases() throws Exception {
		Random rng = new Random();
		int testCases = 10000;

		for (int i = 0; i < testCases; i++) {
                    if(i % 100 == 1){
                        System.out.println(i);
                    }
			double a0 = 16;//rng.nextInt(1<<30)%1000000.0/1000000.0;
			double a1 = 12;//rng.nextInt(1<<30)%1000000.0/1000000.0;
                        double b0 = 35;//rng.nextInt(1<<30)%1000000.0/1000000.0;
			double b1 = 23;//rng.nextInt(1<<30)%1000000.0/1000000.0;
			runThreads(new Helper(a0, b0, a1, b1, Mode.REAL) {
				
				@Override
				public GCSignal[] secureCompute(GCSignal[] a0, GCSignal[] b0, GCSignal[] a1, GCSignal[] b1, int offset, CompEnv<GCSignal> env) throws Exception {
                                    FixedPointLib<GCSignal> lib = new FixedPointLib<GCSignal>(env);
                                    
                                    GCSignal[] a = lib.add(a0, a1);
                                    GCSignal[] b = lib.add(b0, b1);
                                    GCSignal[] c = lib.add(a, b);
                                    GCSignal[] d = lib.sub(a, b);
                                    GCSignal[] e = lib.multiply(d, d, offset);
                                    
                                    return e;
                                    //return lib.divide(e, c, offset);
				}
				
				@Override
				public double plainCompute(double a0, double b0, double a1, double b1) {
                                    double a = a0 + a1;
                                    double b = b0 + b1;
					return (a-b)*(a-b)/(a + b);
				}
			});
		}
	}
        
        public static void main(String[] args) throws Exception {
            SGXBenchmarkGC test = new SGXBenchmarkGC();
            test.testAllCases();
    }
}